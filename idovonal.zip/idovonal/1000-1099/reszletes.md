# Államalapítás – 1000–1099

Szent István királlyá koronázása a magyar államiság alapköve. A keresztény állam megszervezésével megszilárdult a központi hatalom. [...]