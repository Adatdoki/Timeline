# Reformkor és szabadságharc – 1800–1899

Magyarország önállóságáért vívott harc, majd a kiegyezés 1867-ben. [...]