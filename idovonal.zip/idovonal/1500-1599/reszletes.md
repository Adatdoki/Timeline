# Kettős uralom – 1500–1599

A Habsburg és török hatalomharc miatt a királyság megoszlik. [...]