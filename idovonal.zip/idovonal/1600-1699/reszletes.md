# Felszabadítás – 1600–1699

Buda visszafoglalása után a Habsburg uralom megerősödik. [...]