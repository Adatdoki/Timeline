# Fejlődő királyság – 1100–1199

E században a királyi hatalom megszilárdul, az államigazgatás fejlődik. [...]