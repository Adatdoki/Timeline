# Felvilágosult abszolutizmus – 1700–1799

Új gazdasági és oktatási reformok indulnak. [...]